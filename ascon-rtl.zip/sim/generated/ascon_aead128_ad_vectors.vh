// SPDX-License-Identifier: Apache-2.0
// Auto-generated from upstream ascon/ascon-c via tools/ascon_c_aead128_ad_vectors.c.

localparam [127:0] VEC_AEAD_AD_KEY                  = 128'h07060504030201000f0e0d0c0b0a0908;
localparam [127:0] VEC_AEAD_AD_NONCE                = 128'ha7a6a5a4a3a2a1a0afaeadacabaaa9a8;

localparam [31:0] VEC_AEAD_AD_C0_AD_BYTES     = 32'd0;
localparam [31:0] VEC_AEAD_AD_C0_MSG_BYTES    = 32'd0;
localparam [127:0] VEC_AEAD_AD_C0_TAG               = 128'hc60019868061c624f16b719c8c6764c7;

localparam [31:0] VEC_AEAD_AD_C1_AD_BYTES     = 32'd1;
localparam [31:0] VEC_AEAD_AD_C1_MSG_BYTES    = 32'd0;
localparam [127:0] VEC_AEAD_AD_C1_TAG               = 128'hf381d02828b37b4eb6b8a6fdf98a535e;
localparam [127:0] VEC_AEAD_AD_C1_AD0               = 128'h00000000000000800000000000000000;

localparam [31:0] VEC_AEAD_AD_C2_AD_BYTES     = 32'd7;
localparam [31:0] VEC_AEAD_AD_C2_MSG_BYTES    = 32'd1;
localparam [127:0] VEC_AEAD_AD_C2_TAG               = 128'h80bbe74c7f227423639d8a5ec85057db;
localparam [127:0] VEC_AEAD_AD_C2_AD0               = 128'h00868584838281800000000000000000;
localparam [127:0] VEC_AEAD_AD_C2_PT0               = 128'h00000000000000300000000000000000;
localparam [127:0] VEC_AEAD_AD_C2_CT0               = 128'h000000000000005f0000000000000000;

localparam [31:0] VEC_AEAD_AD_C3_AD_BYTES     = 32'd8;
localparam [31:0] VEC_AEAD_AD_C3_MSG_BYTES    = 32'd8;
localparam [127:0] VEC_AEAD_AD_C3_TAG               = 128'ha4faad1cf87a2b875bd8dfefd4b9e03f;
localparam [127:0] VEC_AEAD_AD_C3_AD0               = 128'h87868584838281800000000000000000;
localparam [127:0] VEC_AEAD_AD_C3_PT0               = 128'h37363534333231300000000000000000;
localparam [127:0] VEC_AEAD_AD_C3_CT0               = 128'h2a772422d57551210000000000000000;

localparam [31:0] VEC_AEAD_AD_C4_AD_BYTES     = 32'd9;
localparam [31:0] VEC_AEAD_AD_C4_MSG_BYTES    = 32'd15;
localparam [127:0] VEC_AEAD_AD_C4_TAG               = 128'h57d0de4b1748b717904bc4f0af4bf652;
localparam [127:0] VEC_AEAD_AD_C4_AD0               = 128'h87868584838281800000000000000088;
localparam [127:0] VEC_AEAD_AD_C4_PT0               = 128'h3736353433323130003e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C4_CT0               = 128'hf7bd034d3fc9d2c800cf9f4e02f0ecf4;

localparam [31:0] VEC_AEAD_AD_C5_AD_BYTES     = 32'd15;
localparam [31:0] VEC_AEAD_AD_C5_MSG_BYTES    = 32'd16;
localparam [127:0] VEC_AEAD_AD_C5_TAG               = 128'h6a15a852bd6041d46304630409397003;
localparam [127:0] VEC_AEAD_AD_C5_AD0               = 128'h8786858483828180008e8d8c8b8a8988;
localparam [127:0] VEC_AEAD_AD_C5_PT0               = 128'h37363534333231303f3e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C5_CT0               = 128'he94c079e3b47b0f49f88fd2c09ac9c9a;

localparam [31:0] VEC_AEAD_AD_C6_AD_BYTES     = 32'd16;
localparam [31:0] VEC_AEAD_AD_C6_MSG_BYTES    = 32'd16;
localparam [127:0] VEC_AEAD_AD_C6_TAG               = 128'h3314b498d514cdcf3bf19df16a831c56;
localparam [127:0] VEC_AEAD_AD_C6_AD0               = 128'h87868584838281808f8e8d8c8b8a8988;
localparam [127:0] VEC_AEAD_AD_C6_PT0               = 128'h37363534333231303f3e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C6_CT0               = 128'hda7030cda69a309accb718d3ca29d942;

localparam [31:0] VEC_AEAD_AD_C7_AD_BYTES     = 32'd17;
localparam [31:0] VEC_AEAD_AD_C7_MSG_BYTES    = 32'd17;
localparam [127:0] VEC_AEAD_AD_C7_TAG               = 128'h903d3e4f02d7fa35ccbe8f1759adc90d;
localparam [127:0] VEC_AEAD_AD_C7_AD0               = 128'h87868584838281808f8e8d8c8b8a8988;
localparam [127:0] VEC_AEAD_AD_C7_AD1               = 128'h00000000000000900000000000000000;
localparam [127:0] VEC_AEAD_AD_C7_PT0               = 128'h37363534333231303f3e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C7_CT0               = 128'hcf9ecb58bcff25106fb3868f039a04a6;
localparam [127:0] VEC_AEAD_AD_C7_PT1               = 128'h00000000000000400000000000000000;
localparam [127:0] VEC_AEAD_AD_C7_CT1               = 128'h00000000000000df0000000000000000;

localparam [31:0] VEC_AEAD_AD_C8_AD_BYTES     = 32'd31;
localparam [31:0] VEC_AEAD_AD_C8_MSG_BYTES    = 32'd32;
localparam [127:0] VEC_AEAD_AD_C8_TAG               = 128'h53287244f6a09d9cfb9174484b6111d4;
localparam [127:0] VEC_AEAD_AD_C8_AD0               = 128'h87868584838281808f8e8d8c8b8a8988;
localparam [127:0] VEC_AEAD_AD_C8_AD1               = 128'h9796959493929190009e9d9c9b9a9998;
localparam [127:0] VEC_AEAD_AD_C8_PT0               = 128'h37363534333231303f3e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C8_CT0               = 128'hd312d728d11a31589d2664c4df979fa6;
localparam [127:0] VEC_AEAD_AD_C8_PT1               = 128'h47464544434241404f4e4d4c4b4a4948;
localparam [127:0] VEC_AEAD_AD_C8_CT1               = 128'hc8a2f7d3abac11a10006d8481d043381;

localparam [31:0] VEC_AEAD_AD_C9_AD_BYTES     = 32'd32;
localparam [31:0] VEC_AEAD_AD_C9_MSG_BYTES    = 32'd31;
localparam [127:0] VEC_AEAD_AD_C9_TAG               = 128'h86870a2331e38eb2c3ad86a778265c7b;
localparam [127:0] VEC_AEAD_AD_C9_AD0               = 128'h87868584838281808f8e8d8c8b8a8988;
localparam [127:0] VEC_AEAD_AD_C9_AD1               = 128'h97969594939291909f9e9d9c9b9a9998;
localparam [127:0] VEC_AEAD_AD_C9_PT0               = 128'h37363534333231303f3e3d3c3b3a3938;
localparam [127:0] VEC_AEAD_AD_C9_CT0               = 128'h56239bea8d030336b40055cd779847e6;
localparam [127:0] VEC_AEAD_AD_C9_PT1               = 128'h4746454443424140004e4d4c4b4a4948;
localparam [127:0] VEC_AEAD_AD_C9_CT1               = 128'h6253e346ba752c1a00782566c3073bdf;

